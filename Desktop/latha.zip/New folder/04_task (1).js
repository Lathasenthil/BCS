var Radi = window.prompt("Enter a Radius Value")
//var areas = (Radi * Radi) * 3.14159
var areas = Radi**2 * 3.14159


console.log(`The Area for given ${Radi}cm radius is ${areas}cm²`)