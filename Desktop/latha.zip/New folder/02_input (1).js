console.log("hello")
window.alert("super")
window.confirm("are you student")  // gives two buttons ok and cancel
var age = +window.prompt("enter your age") //  input textbox show aagum

//  + --> string to number
 
 