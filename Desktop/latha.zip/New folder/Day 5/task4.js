// task-16

// var PI = 3.14;
// var radius = window.prompt("Enter the radius in cm:");
// // var area = PI * radius * radius;
// var area = PI * radius ** 2;
// console.log(area);
// console.log(`The Area for the given ${radius}cm radius is ${area}cm²`);
// console.log(
//   `The Area for the given ${radius}cm radius is ${PI * radius ** 2}cm²`
// );

// task-17

// console.log((7 > 5 && 2 < 1) || 8 != 0);

// task-18

// const stock = ["eye of newt", "bat wing", "toad slime", "mandrake root"];

// const ingredient = prompt("Enter an ingredient:").toLowerCase();

// if (stock.includes(ingredient)) {
//   console.log("In stock!");
// } else {
//   console.log("Out of stock.");
// }

// task -19

// var spellName = "Fireball"; // Fixed spell name
// var power = Math.floor(Math.random() * 100) + 1; // Random power between 1–100
// var category;

// if (power >= 90) {
//   category = "Legendary";
// } else if (power >= 60) {
//   category = "Advanced";
// } else {
//   category = "Basic";
// }

// console.log("Spell Name: " + spellName);
// console.log("Power: " + power);
// console.log("Category: " + category);

// task-20
// var x = window.prompt("enter your name");
// x.trim().toLowerCase();
// console.log(`${x}@hogwarts.com`);
