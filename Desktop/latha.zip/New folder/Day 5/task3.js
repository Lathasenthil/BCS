//  Task -11
// var m = window.prompt("Tell me your model name");
// var p = window.prompt("Tell me your price");

// var model = prompt("Model name?");
// var price = +prompt("Price?");
// let total = price + price * 0.1;
// console.log(`${model} will cost you ${total} Galleons (after tax).`);

// // task-12
//  var item = window.prompt("Enter your order:");
// console.log(item.toLowerCase());

// task-13
// var n = "  Hermione ";
// x=n.toLowerCase().trim();
// console.log(x);

// task-14

// var input = window.prompt("Ask for a day number");

// var days = {
//   1: "Monday",
//   2: "Tuesday",
//   3: "Wednesday",
//   4: "Thursday",
//   5: "Friday",
//   6: "Saturday",
//   7: "Sunday",
// };
// if (input >= 1 && input <= 7) {
//   var x = [days == 7];
//   days === 7;
//   console.log(`${days}`);
// } else {
//   console.log("sunday");
// }

// if (1 == "Monday") {
//   console.log("It's Monday. Store is open!");
// } else if (2 == "Tuesday") {
//   console.log("It's Tuesday. Store is open!");
// } else if (3 == "Wednesday") {
//   console.log("It's Wednesday. Store is open!");
// } else if (4 == "Thursday.") {
//   console.log("It's Thursday. Store is open!");
// } else if (5 == "Friday") {
//   console.log("It's Friday. Store is open!");
// } else if (6 == " Saturday") {
//   console.log("It's Saturday Store is open!");
// } else {
//   console.log("It's Sunday Store is Closed!");
// }

// task -15

// var c = prompt("Temperature in °C:");
// var f = (c * 9) / 5 + 32;

// if (f < 60) {
//   console.log("Too cold!");
// } else if (f > 100) {
//   console.log("Too hot!");
// } else {
//   console.log("Temparature is normal.");
// }
