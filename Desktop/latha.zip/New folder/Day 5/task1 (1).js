// // Setup

// // tasck -1
// var wandCore = window.prompt("What is your wand core?");
// console.log(wandCore.toLowerCase());
// console.log(wandCore.toUpperCase());

// Tasck 2;
// var age = +window.prompt("Enter your age:");
// if (age >= 11) {
//   console.log("Welcome to Hogwarts! 🦉");
// } else {
//   console.log("You're a bit too young for Hogwarts, try again later. 👶");
// }

// Tasck 3
// var galleons = +window.prompt("Enter Galleons:");

// k = galleons * 493;
// console.log(`${galleons} Galleons = ${k} Knuts`);

// Tasck 4

// var password = window.prompt("Speak the password:");
// password = password.trim().toLowerCase();
// var p = "alohomora";
// if (password == p) {
//   console.log("Access granted to the Chamber of Secrets.");
// } else {
//   console.log("Incorrect password. 🐍");
// }

// Tasck -5
// var trait = window.prompt("What quality do you value most?");
// trait = trait.toLowerCase();

// if (trait == "bravery") {
//   console.log("You belong to Gryffindor!");
// } else if (trait == "wisdom") {
//   console.log("You belong to Ravenclaw!");
// } else if (trait == "loyalty") {
//   console.log("You belong to Hufflepuff!");
// } else if (trait == "ambition") {
//   console.log("You belong to Slytherin");
// } else if (trait == "others") {
//   console.log("You belong to Squib");
// } else {
// console.log("not most quailty")
// }
