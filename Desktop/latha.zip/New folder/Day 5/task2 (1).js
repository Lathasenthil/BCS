// // Task -6
// var person1Name = window.prompt("Enter person1 name:");
// var person2Name = window.prompt("Enter person2 name:");
// var person1Height = +window.prompt(`${person1Name} tell me your height in cm:`);
// var person2Height = +window.prompt(`${person2Name} tell me your height in cm:`);

// var difference = Math.abs(person1Height - person2Height);

// if (person1Height > person2Height) {
//   console.log(
//     `${person1Name} is taller than ${person2Name} by ${difference}cm`
//   );
// } else if (person1Height == person2Height) {
//   console.log(`${person1Name} and ${person2Name} are of same height`);
// } else {
//   console.log(
//     `${person2Name} is taller than ${person1Name} by ${difference}cm`
//   );
// }

// Task -7

// let goals = parseInt(prompt("How many goals did your team score?"));
// let totalScore = goals * 10;

// if (totalScore >= 200) {
//   console.log(`You scored ${totalScore}points and won the match! 🧹🏆`);
// } else {
//   console.log(`You scored ${totalScore} points. Better luck next time!`);
// }

// Task-8

// console.log("Gryffindor".padStart(15));
// console.log("Ravenclaw".padStart(15));
// console.log("Hufflepuff".padStart(15));
// console.log("Slytherin".padStart(15));

// Task-9
// var x = window.prompt("Ask for a number ");
// if (x < 6) {
//   console.log(`Access to Vault ${x} granted`);
// } else {
//   console.log("Invalid vault number.");
// }

// Task -10
// console.log("Expecto Patronum".repeat(7));


