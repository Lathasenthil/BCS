### dedocks attack

# stucture of a web browser 
  user Interface 
  Browser Engine 
  Render Tree
  Network --JS engine -- UI Backend

Data Storage 

### cookies 
 - inspact --> Application--> Cookies ( you will see cookies )

 dns propocaion

 # javaScript 
 netscape 1995
  livewire then livescript
  nrandon eich
  ecmascript
   
   tc39 =-- technecal committee
   
  ### Alert is using to stop rendering a file

  