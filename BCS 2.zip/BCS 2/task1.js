// var name = "Gopi"; 

// console.log(name.toLowerCase());
// console.log(name.toUpperCase());

// ### Answer gopi /Gopi 


// var quote = "  Do Good, Be Good ";

// console.log(name.toLowerCase());
// console.log(name.toUpperCase());

// var quote = "  Do Good, Be Good ";

// console.log(quote.trim());-Do Good, Be Good

// var quote = "  Do Good, Be Good ";

// console.log(quote.toLowerCase().trim());-do good, be good 

// var quote = "  Do Good, Be Good ";
// console.log("🎊".repeat(10)); -🎊🎊🎊🎊🎊🎊🎊🎊🎊🎊

// var quote = "  Do Good, Be Good   "

// console.log(quote.trimLeft());-Do Good, Be Good trim in left 

//  var quote = "  Do Good, Be Good "

// console.log(quote.trimStart());-Do Good, Be Good

// var quote = "  Do Good, Be Good "

// console.log(quote.trimEnd());-Do Good, Be Good

// const quote = "  Do Good, Be Good "

// console.log(quote.length);- 19

// var english = 70;
// var maths = 90;
// var science = 97;
// var social = 80;

// var marks = [70, 90, 97, 80];

// console.log(marks);- 4 (0-70/1-90/2-97/3-80)

// var english = 70;
// var maths = 90;
// var science = 97;
// var social = 80;

// var marks = [70, 90, 97, 80];

// console.log(marks[0]);
// console.log(marks[1]);
// console.log(marks[2]);
// console.log(marks[3]);
// console.log(marks[4]);

// var avengers = [
//   "Hulk",
//   "Iron man",
//     "Black widow",
//       "Captain america",
//         "Spider man",
//           "Thor",
//           ];

//           console.log(avengers);

// var student = {
//     "name": "Arjuna",
//     "age" : 20,
//     "college": "SAC"
// }
//  console.log(student);-{name: 'Arjuna', age: 20, college: 'SAC'}

// var student = {
//     name: "Arjuna",
//     age : 20,
//     college: "SAC",
//       Rich: true,
//         "personal hobbies": ["Hockey", "Traveling", "Cricket"],
// }

//  console.log(student["personal hobbies"]);(3) ['Hockey', 'Traveling', 'Cricket']
// // console.log(student.personal hobbies) ❌ result is undefined 

// var marks = {
//   0: 70,
//   1: 90,
//   2: 97,
//   3: 80,
// };

// console.log(marks);
// console.log(typeof marks);
// console.log(typeof student);


// var balance = 10_000;

// console.log(balance);- 10000  


// var name = "Gopi";
// var name = "Muthu"; 

// console.log(name);Muthu

// let name1 = "Gopi";

// console.log(name1);Muthu 


// var name = "Muthu"; 

// console.log(name);

// let name1 = "Gopi";

// console.log(name1);

// const x = 5;
// const y = "5";

// console.log(x == y); // true // allows coercions

// const x = 5;
// const y = "5";

// console.log(x === y); // false // doesn't allows coercions

// const t1 = [100, 200]; 
// const t2 = [100, 200];
// const t3 = t1; 

// console.log(t1);- array(2)/0-100/1-200/length-2

// const t1 = [100, 200]; 
// const t2 = [100, 200];
// const t3 = t1; 

// console.log(t1 == t2); False


// const t1 = [100, 200]; 
// const t2 = [100, 200];
// const t3 = t1; 

//  console.log(t1 === t2);False different address is false


// const t1 = [100, 200]; 
// const t2 = [100, 200];
// const t3 = t1; 

//  console.log(t1 === t3);true

// const t1 = [100, 200]; 
// const t2 = [100, 200];
// const t3 = t1; 

//  console.log(t1 == t3);true same addreess is true

// const r1 = [100, 400];
// const r2 = [700, 900];

// const r3 = [...r1, ...r2];

// console.log(r3);length 4 


